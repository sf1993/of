﻿# -*- coding: utf-8 -*-
#------------------------------------------------------------
# jami
#------------------------------------------------------------
# Licença: GPL (http://www.gnu.org/licenses/gpl-3.0.html)
# Baseado no código do addon youtube
#------------------------------------------------------------

import xbmc, xbmcaddon, xbmcplugin, os, sys, plugintools

from addon.common.addon import Addon

addonID = 'plugin.video.jami'
addon   = Addon(addonID, sys.argv)
local   = xbmcaddon.Addon(id=addonID)
icon    = local.getAddonInfo('icon')
base    = 'plugin://plugin.video.youtube/'

icon1 = 'http://static.fnac-static.com/multimedia/PT/images_produits/PT/ZoomPE/1/6/8/0602537176861.jpg'
icon2 = 'http://static.fnac-static.com/multimedia/PT/images_produits/PT/ZoomPE/6/8/6/0602527851686.jpg'
icon3 = 'http://videosinfantis.pt/wp-content/uploads/2013/09/Ruca_5.jpg'
icon4 = 'http://vignette3.wikia.nocookie.net/pocoyoworld/images/2/2f/Pocoyo-Image-300x300_Pato_Elly_Loula_Sleepy_Bird.jpg/revision/latest?cb=20140101011604'
icon5 = 'http://vignette4.wikia.nocookie.net/doblaje/images/a/aa/Jelly_Jamm.jpg/revision/latest?cb=20120728140403&path-prefix=es'
icon6 = 'https://scontent.cdninstagram.com/t51.2885-19/s150x150/12965714_546124852233591_2033050455_a.jpg'
icon7 = 'https://pbs.twimg.com/profile_images/608590304514441216/BS7MfUjz_400x400.jpg'
icon8 = 'https://patrick44.files.wordpress.com/2012/01/patrickschultzcollage21.jpg'
icon9 = 'http://www.difundir.com.br/fotos/01942_49240p3.jpg'

def run():
    plugintools.log("jami.run")
    
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        action = params.get("action")
        exec action+"(params)"
    
    plugintools.close_item_list()

def main_list(params):
		plugintools.log("jami ===> " + repr(params))

		plugintools.add_item(title = "Panda e os Caricas"            , url = base + "channel/UCvw-R-r3p6Hc-yj1qyoPslQ/"                   , thumbnail = icon1, folder = True)
		plugintools.add_item(title = "Xana Toc Toc"                   , url = base + "user/XanaTocTocVEVO/", thumbnail = icon2, folder = True)
		plugintools.add_item(title = "Ruca"                          , url = base + "user/JoaoCarlosG2010/"                , thumbnail = icon3, folder = True)	

		plugintools.add_item(title = "Pocoyo"                       , url = base + "user/childrenvideos/", thumbnail = icon4, folder = True)	

                plugintools.add_item(title = "Jelly Jamm"                    , url = base + "user/JellyJammPortugues/"               , thumbnail = icon5, folder = True)	
              
		plugintools.add_item(title = "Mundo Animado"                                    , url = base + "channel/UCOre4lsfRMaC62bOHUjPp2Q/"           , thumbnail = icon6, folder = True)	

		plugintools.add_item(title = "Disney Portugal"                            , url = base + "channel/UCF41Om13uiorwWbD-BZivEw/", thumbnail = icon7, folder = True)
		plugintools.add_item(title = "Looney Tunes"                                , url = base + "channel/UCItsJgbVelzGpw4JyFRiA8w/", thumbnail = icon8, folder = True)
		plugintools.add_item(title = "Turma da Mónica"                            , url = base + "channel/UCV4XcEqBswMCryorV_gNENw/", thumbnail = icon9, folder = True)
		
		xbmcplugin.setContent(int(sys.argv[1]), 'movies')
		xbmc.executebuiltin('Container.SetViewMode(500)')
		
run()
